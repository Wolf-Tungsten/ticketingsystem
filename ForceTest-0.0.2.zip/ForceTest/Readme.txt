一种不同思路的可线性化测试

使用方法：
1.将 ForceTest.java 复制到 ticketingsystem 目录下
2.运行 force-test.sh
(ForceTest是一个包含main的类，只要运行它就可以了)